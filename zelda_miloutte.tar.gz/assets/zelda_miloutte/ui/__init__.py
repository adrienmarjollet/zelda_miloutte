"""UI components module."""
